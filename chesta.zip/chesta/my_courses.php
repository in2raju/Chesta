<?php
session_start();
require 'db.php';
require 'config_payment.php';        // h(), en_to_bn()
require 'course_performance.php';

// Ensure user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

// Logged-in user info
$user     = $_SESSION['user'];
$userId   = $user['user_id'] ?? $user['id'] ?? '';
$userMail = trim($user['email'] ?? '');       // exam_results-এ dashboard এই আইডি ব্যবহার করে
$userType = (int)($user['user_type_id'] ?? 0);
$orgCode  = $user['org_code'] ?? '';
$brCode   = $user['br_code'] ?? '';

$perf    = get_course_performance($pdo, $userId, $userMail !== '' ? $userMail : $userId);
$courses = $perf['courses'];
$ov      = $perf['overall'];

$bn  = fn($v) => en_to_bn((string)$v);
$pc  = fn($v) => $v === null ? '—' : en_to_bn((string)$v) . '%';
$dt  = fn($d) => $d ? date('d M, Y', strtotime($d)) : '—';

$chartLabels = array_map(fn($c) => $c['name'], $courses);
$chartDone   = array_map(fn($c) => (float)$c['completion'], $courses);
$chartAvg    = array_map(fn($c) => (float)($c['avg'] ?? 0), $courses);
$jf = JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
?>

<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>My Courses</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- ✅ Google Fonts লিংক সরানো হয়েছে — ব্রাউজারের ডিফল্ট ফন্ট ব্যবহার হবে -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
    /* কাস্টম গ্রিন ডিজাইন — .cpg র‍্যাপারে সীমিত, প্রিফিক্স "cp-" */
    .cpg{
        --ink:#10231a;--mut:#5a6c62;--line:#e1e9e3;--surface:#f2f6f3;--card:#fff;
        --g:#00693e;--g2:#0a8f55;--gl:#e4f2e9;--r:#f42a41;--rl:#fdecee;
        --gold:#d9a441;--goldl:#fdf3e0;
        color:var(--ink);
        line-height:1.65;
        /* ✅ font-family সরানো হয়েছে — ইউজারের ব্রাউজার/সিস্টেমের ডিফল্ট ফন্ট ব্যবহার হবে */
    }
    .cpg *,.cpg *::before,.cpg *::after{box-sizing:border-box}
    .cpg :focus-visible{outline:3px solid var(--g);outline-offset:2px}
    .cp-title{font-size:1.5rem;font-weight:700;margin:0 0 16px}
    .cp-h2{font-size:1.1rem;font-weight:700;margin:26px 0 12px}
    .cp-msg{padding:12px 14px;border-radius:12px;font-size:.93rem;margin-bottom:14px;border:1px solid}
    .cp-msg.info{background:var(--goldl);color:#8a5a00;border-color:var(--gold)}
    .cp-msg.err{background:var(--rl);color:var(--r);border-color:var(--r)}
    .cp-kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:6px}
    @media(max-width:900px){.cp-kpis{grid-template-columns:repeat(2,1fr)}}
    .cp-kpi{border-radius:20px;padding:18px 20px;color:#fff;box-shadow:0 14px 34px -20px rgba(2,74,44,.45)}
    .cp-kpi span{display:block;font-size:.8rem;font-weight:600;opacity:.9}
    .cp-kpi b{display:block;font-size:2rem;line-height:1.25;font-weight:700}
    .cp-kpi small{opacity:.88;font-size:.8rem}
    .cp-k1{background:linear-gradient(135deg,var(--g),var(--g2))}
    .cp-k2{background:linear-gradient(135deg,#0a8f55,#3fc088)}
    .cp-k3{background:linear-gradient(135deg,#3b82a0,#63b3d0)}
    .cp-k4{background:linear-gradient(135deg,var(--gold),#f5c35c);color:#3a2600}
    .cp-panel{background:var(--card);border:1px solid var(--line);border-radius:20px;padding:22px;box-shadow:0 14px 34px -24px rgba(2,74,44,.35)}
    .cp-bar{height:10px;background:var(--surface);border-radius:99px;overflow:hidden}
    .cp-bar i{display:block;height:100%;border-radius:99px;background:linear-gradient(90deg,var(--g),var(--g2))}
    .cp-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:18px}
    @media(max-width:420px){.cp-grid{grid-template-columns:1fr}}
    .cp-card{background:var(--card);border:1px solid var(--line);border-radius:20px;overflow:hidden;box-shadow:0 14px 34px -24px rgba(2,74,44,.35);display:flex;flex-direction:column}
    .cp-top{padding:20px;color:#fff}
    .cp-top h3{font-size:1.15rem;font-weight:700;margin:0;color:#fff;line-height:1.35}
    .cp-top p{margin:4px 0 0;font-size:.82rem;opacity:.9}
    .cp-body{padding:18px 20px;display:grid;gap:14px;flex:1}
    .cp-row{display:flex;justify-content:space-between;font-size:.88rem;margin-bottom:5px}
    .cp-row b{font-weight:700}
    .cp-stats{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;text-align:center}
    .cp-stats div{background:var(--surface);border-radius:12px;padding:8px 4px}
    .cp-stats b{display:block;font-size:1.1rem}
    .cp-stats small{color:var(--mut);font-size:.74rem}
    .cp-det summary{cursor:pointer;font-weight:600;font-size:.9rem;color:var(--g);list-style:none}
    .cp-det summary::-webkit-details-marker{display:none}
    .cp-det summary::after{content:" ▾"}
    .cp-det[open] summary::after{content:" ▴"}
    .cp-ex{display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid var(--line);font-size:.88rem}
    .cp-ex:last-child{border:0}
    .cp-ex .t{flex:1;min-width:0}
    .cp-ex .t small{display:block;color:var(--mut);font-size:.76rem}
    .cp-pill{display:inline-block;padding:2px 12px;border-radius:99px;font-size:.75rem;font-weight:700}
    .cp-pill.ok{background:var(--gl);color:var(--g)}
    .cp-pill.wait{background:var(--goldl);color:#8a5a00}
    .cp-go{background:linear-gradient(135deg,var(--g),var(--g2));color:#fff;border-radius:99px;padding:5px 14px;font-size:.78rem;font-weight:700;text-decoration:none;white-space:nowrap}
    .cp-go:hover{color:#fff}
    .cp-empty{text-align:center;padding:44px 16px;background:var(--card);border:1px dashed var(--line);border-radius:20px;color:var(--mut)}
    .cp-empty a{display:inline-block;margin-top:12px;background:linear-gradient(135deg,var(--g),var(--g2));color:#fff;padding:10px 26px;border-radius:99px;text-decoration:none;font-weight:700}
    .cp-open{display:flex;align-items:center;justify-content:center;background:linear-gradient(135deg,var(--g),var(--g2));color:#fff;border-radius:99px;padding:10px 18px;font-weight:700;font-size:.9rem;text-decoration:none}
    .cp-open:hover{color:#fff}
    </style>
</head>
<body class="d-flex flex-column min-vh-100">
<?php include 'header.php'; ?>

<main class="container py-4 flex-grow-1">
<div class="cpg">
    <h1 class="cp-title">আমার কোর্স</h1>

    <?php foreach ($perf['verifying'] as $v): ?>
        <div class="cp-msg info">⏳ <strong><?= h($v['name']) ?></strong> — পেমেন্ট যাচাই চলছে। অনুমোদনের পর কোর্সটি এখানে দেখা যাবে।</div>
    <?php endforeach; ?>

    <?php if (!$perf['results_ok'] && $courses): ?>
        <div class="cp-msg err">পরীক্ষার ফলাফলের তথ্য পড়া যায়নি (course_performance.php-এর <code>CP_RES_*</code> কলামের নাম মিলিয়ে নিন)। কোর্সের তালিকা দেখানো হচ্ছে।</div>
    <?php endif; ?>

    <?php if (!$courses): ?>
        <div class="cp-empty">
            <p>আপনি এখনো কোনো কোর্সে ভর্তি হননি।</p>
            <a href="index_user.php#courses">কোর্স দেখুন</a>
        </div>
    <?php else: ?>

        <!-- সামগ্রিক পারফরম্যান্স -->
        <h2 class="cp-h2" style="margin-top:0">সামগ্রিক পারফরম্যান্স</h2>
        <div class="cp-kpis">
            <div class="cp-kpi cp-k1"><span>ভর্তি করা কোর্স</span><b><?= $bn($ov['courses']) ?> টি</b><small>সক্রিয় কোর্স</small></div>
            <div class="cp-kpi cp-k2"><span>সম্পন্ন পরীক্ষা</span><b><?= $bn($ov['attempted']) ?>/<?= $bn($ov['total']) ?></b><small>বাকি <?= $bn($ov['pending']) ?> টি</small></div>
            <div class="cp-kpi cp-k3"><span>গড় স্কোর</span><b><?= $pc($ov['avg']) ?></b><small>প্রতি পরীক্ষার সেরা ফলাফল ধরে</small></div>
            <div class="cp-kpi cp-k4"><span>সর্বোচ্চ স্কোর</span><b><?= $pc($ov['best']) ?></b><small>এ পর্যন্ত</small></div>
        </div>
        <div class="cp-panel" style="margin-top:14px">
            <div class="cp-row"><span>মোট অগ্রগতি</span><b><?= $pc($ov['completion']) ?></b></div>
            <div class="cp-bar"><i style="width:<?= (float)$ov['completion'] ?>%"></i></div>
        </div>

        <!-- কোর্সভিত্তিক চার্ট -->
        <?php if (count($courses) > 0 && $ov['total'] > 0): ?>
        <h2 class="cp-h2">কোর্সভিত্তিক তুলনা</h2>
        <div class="cp-panel"><div style="height:300px"><canvas id="cpChart"></canvas></div></div>
        <?php endif; ?>

        <!-- কোর্স কার্ড -->
        <h2 class="cp-h2">কোর্সভিত্তিক পারফরম্যান্স</h2>
        <div class="cp-grid">
        <?php foreach ($courses as $c): ?>
            <article class="cp-card">
                <div class="cp-top" style="background:<?= h($c['tone']) ?>">
                    <h3><?= h($c['name']) ?></h3>
                    <p><?= $c['subtitle'] ? h($c['subtitle']) . ' · ' : '' ?><?= $c['expires_at'] ? 'মেয়াদ: ' . h($dt($c['expires_at'])) : 'আজীবন' ?></p>
                </div>
                <div class="cp-body">
                    <?php if ($c['total'] === 0): ?>
                        <p style="margin:0;color:var(--mut);font-size:.9rem">এই কোর্সে এখনো কোনো পরীক্ষা যোগ করা হয়নি।</p>
                    <?php else: ?>
                        <div>
                            <div class="cp-row"><span>অগ্রগতি (<?= $bn($c['attempted']) ?>/<?= $bn($c['total']) ?>)</span><b><?= $pc($c['completion']) ?></b></div>
                            <div class="cp-bar"><i style="width:<?= (float)$c['completion'] ?>%"></i></div>
                        </div>
                        <div>
                            <div class="cp-row"><span>গড় স্কোর</span><b style="color:<?= cp_score_color($c['avg']) ?>"><?= $pc($c['avg']) ?></b></div>
                            <div class="cp-bar"><i style="width:<?= (float)($c['avg'] ?? 0) ?>%;background:<?= cp_score_color($c['avg']) ?>"></i></div>
                        </div>
                        <div class="cp-stats">
                            <div><b><?= $pc($c['best']) ?></b><small>সর্বোচ্চ</small></div>
                            <div><b><?= $bn($c['pending']) ?></b><small>বাকি পরীক্ষা</small></div>
                            <div><b><?= $c['last_date'] ? h($dt($c['last_date'])) : '—' ?></b><small>শেষ অংশগ্রহণ</small></div>
                        </div>

                        <details class="cp-det">
                            <summary>পরীক্ষার তালিকা (<?= $bn($c['total']) ?>)</summary>
                            <div style="margin-top:8px">
                            <?php foreach ($c['exams'] as $e): ?>
                                <div class="cp-ex">
                                    <div class="t"><?= h($e['title'] ?? '—') ?>
                                        <small><?= $e['done']
                                            ? 'চেষ্টা ' . $bn($e['attempts']) . ' বার' . ($e['last_date'] ? ' · ' . h($dt($e['last_date'])) : '')
                                            : ($e['exam_date'] ? h($dt($e['exam_date'])) : 'তারিখ নির্ধারিত নেই') ?></small></div>
                                    <?php if ($e['done']): ?>
                                        <strong style="color:<?= cp_score_color($e['pct']) ?>"><?= $pc($e['pct']) ?></strong>
                                        <a class="cp-go" href="view_exam.php?id=<?= urlencode((string)$e['exam_id']) ?>">আবার</a>
                                    <?php else: ?>
                                        <span class="cp-pill wait">বাকি</span>
                                        <a class="cp-go" href="view_exam.php?id=<?= urlencode((string)$e['exam_id']) ?>">শুরু করুন</a>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                            </div>
                        </details>
                        <a class="cp-open" href="exam_list.php?course_id=<?= (int)$c['id'] ?>">এই কোর্সের সব পরীক্ষা দেখুন →</a>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
</main>

<?php include 'footer.php'; ?>
<?php if ($courses && $ov['total'] > 0): ?>
<script>
(function () {
    var el = document.getElementById('cpChart');
    if (!el || typeof Chart === 'undefined') return;
    /* ✅ Chart.defaults.font.family সরানো হয়েছে — ব্রাউজারের ডিফল্ট ফন্ট ব্যবহার হবে */
    new Chart(el.getContext('2d'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($chartLabels, $jf) ?>,
            datasets: [
                { label: 'অগ্রগতি (%)',  data: <?= json_encode($chartDone, $jf) ?>, backgroundColor: '#00693e', borderRadius: 8 },
                { label: 'গড় স্কোর (%)', data: <?= json_encode($chartAvg,  $jf) ?>, backgroundColor: '#d9a441', borderRadius: 8 }
            ]
        },
        options: {
            responsive: true, maintainAspectRatio: false,
            scales: { y: { beginAtZero: true, max: 100, ticks: { callback: function (v) { return v + '%'; } } } },
            plugins: { legend: { position: 'bottom' } }
        }
    });
})();
</script>
<?php endif; ?>
</body>
</html>