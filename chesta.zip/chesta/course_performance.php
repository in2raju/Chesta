<?php
/* =========================================================
   course_performance.php
   ইউজারের ভর্তি করা কোর্সগুলোর কোর্সভিত্তিক ও সামগ্রিক পারফরম্যান্স হিসাব।
   ব্যবহার: my_courses.php এবং dashboard_my_courses.php
   ========================================================= */

/* ---- exam_results টেবিলের কলাম (আপনার স্কিমা অনুযায়ী) ---- */
const CP_RES_TABLE = 'exam_results';
const CP_RES_USER  = 'user_id';
const CP_RES_EXAM  = 'exam_id';
const CP_RES_SCORE = 'score_pct';        // সরাসরি শতকরা স্কোর (decimal 5,2)
const CP_RES_TOTAL = null;               // score_pct আগে থেকেই % তাই পূর্ণমান লাগে না
const CP_RES_DATE  = 'submitted_at';     // অংশগ্রহণের সময়

/* ✅ MATCH MODE:
   - 'course'  → exams_info.course_id = courses.id  (RECOMMENDED)
   - 'level'   → পুরাতন পদ্ধতি: level_id + exam_type_id মিলিয়ে
*/
const CP_MATCH_MODE = 'course';

/* true করলে course_exams টেবিল থেকেও পরীক্ষা ধরা হয় (manage_course_exams.php দিয়ে হাতে যোগ করা) */
const CP_MANUAL_EXAMS = false;

function cp_ident($s): string {
    $s = (string)$s;
    return preg_match('/^[A-Za-z0-9_]+$/', $s) ? $s : '';
}

/**
 * @param string $enrollUserId  course_enrollments.user_id  (session user_id)
 * @param string $resultUserId  exam_results-এর ইউজার আইডি (dashboard-এ session email); ফাঁকা হলে enrollUserId
 */
function get_course_performance(PDO $pdo, string $enrollUserId, string $resultUserId = ''): array
{
    $out = [
        'courses'    => [],
        'overall'    => ['courses' => 0, 'total' => 0, 'attempted' => 0, 'pending' => 0,
                         'completion' => 0, 'avg' => null, 'best' => null],
        'verifying'  => [],
        'results_ok' => true,
    ];
    if ($enrollUserId === '') return $out;
    if ($resultUserId === '') $resultUserId = $enrollUserId;

    /* যাচাই চলছে এমন কোর্স */
    $st = $pdo->prepare("SELECT DISTINCT c.id, COALESCE(NULLIF(c.title_bn,''), c.title) AS name
                         FROM payments p JOIN courses c ON c.id = p.course_id
                         WHERE p.user_id = ? AND p.status = 'verifying'");
    $st->execute([$enrollUserId]);
    $out['verifying'] = $st->fetchAll(PDO::FETCH_ASSOC);

    /* সক্রিয় কোর্স */
    $st = $pdo->prepare("SELECT c.id, COALESCE(NULLIF(c.title_bn,''), c.title) AS name, c.subtitle, c.tone_gradient,
                                e.enrolled_at, e.expires_at
                         FROM course_enrollments e
                         JOIN courses c ON c.id = e.course_id
                         WHERE e.user_id = ? AND e.status = 'active'
                           AND (e.expires_at IS NULL OR e.expires_at > NOW())
                           AND c.DELETE_DATE IS NULL
                         ORDER BY e.enrolled_at DESC");
    $st->execute([$enrollUserId]);
    $courses = $st->fetchAll(PDO::FETCH_ASSOC);
    if (!$courses) return $out;

    /* কোর্সের পরীক্ষাগুলো */
    $ids = array_map(fn($c) => (int)$c['id'], $courses);
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $okExam = "ei.DELETE_DATE IS NULL AND (ei.AUTHORIZED_STATUS = 'Y' OR ei.AUTHORIZED_STATUS IS NULL)";

    $parts = []; $params = [];

    // ✅ (ক) প্রধান ম্যাচিং: exams_info.course_id = courses.id
    if (CP_MATCH_MODE === 'course') {
        $parts[] = "SELECT c.id AS course_id, ei.exam_id, ei.title, ei.exam_date
                    FROM courses c
                    JOIN exams_info ei ON ei.course_id = c.id
                    WHERE c.id IN ($in)
                      AND $okExam";
        $params = array_merge($params, $ids);
    }
    // (ক') পুরাতন: level + type ম্যাচিং
    elseif (CP_MATCH_MODE === 'level') {
        $parts[] = "SELECT c.id AS course_id, ei.exam_id, ei.title, ei.exam_date
                    FROM courses c
                    JOIN exams_info ei ON ei.level_id = c.level_id AND ei.exam_type_id = c.type_id
                    WHERE c.id IN ($in)
                      AND c.level_id IS NOT NULL AND c.type_id IS NOT NULL AND c.type_id > 0
                      AND $okExam";
        $params = array_merge($params, $ids);
    }

    // (খ) হাতে যোগ করা: course_exams টেবিল
    if (CP_MANUAL_EXAMS) {
        $parts[] = "SELECT ce.course_id, ei.exam_id, ei.title, ei.exam_date
                    FROM course_exams ce
                    JOIN exams_info ei ON ei.exam_id = ce.exam_id
                    WHERE ce.course_id IN ($in) AND $okExam";
        $params = array_merge($params, $ids);
    }

    $examsByCourse = [];
    if ($parts) {
        $st = $pdo->prepare(implode(' UNION ', $parts) . " ORDER BY exam_date ASC, exam_id ASC");
        $st->execute($params);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $examsByCourse[(int)$r['course_id']][] = $r;
        }
    }

    /* ইউজারের ফলাফল: প্রতি পরীক্ষায় সেরা %, চেষ্টার সংখ্যা, শেষ তারিখ */
    $res = [];
    try {
        $t = cp_ident(CP_RES_TABLE); $u = cp_ident(CP_RES_USER); $x = cp_ident(CP_RES_EXAM);
        $s = cp_ident(CP_RES_SCORE); $tot = cp_ident(CP_RES_TOTAL); $d = cp_ident(CP_RES_DATE);
        if (!$t || !$u || !$x || !$s) throw new PDOException('exam_results config invalid');

        $pct     = $tot ? "(er.$s / NULLIF(er.$tot, 0) * 100)" : "er.$s";
        $dateSel = $d ? "MAX(er.$d)" : "NULL";

        $st = $pdo->prepare("SELECT er.$x AS exam_id, COUNT(*) AS attempts, MAX($pct) AS best_pct, $dateSel AS last_date
                             FROM $t er WHERE er.$u = ? GROUP BY er.$x");
        $st->execute([$resultUserId]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $res[(string)$r['exam_id']] = $r;
        }
    } catch (PDOException $e) {
        $out['results_ok'] = false;
        error_log('course_performance results: ' . $e->getMessage());
    }

    /* কোর্সভিত্তিক হিসাব */
    $seen = [];   // একই পরীক্ষা একাধিক কোর্সে থাকলে সামগ্রিক হিসাবে একবারই গোনা হবে
    foreach ($courses as $c) {
        $exams = []; $att = 0; $sum = 0.0; $n = 0; $best = null; $last = null;

        foreach ($examsByCourse[(int)$c['id']] ?? [] as $e) {
            $k    = (string)$e['exam_id'];
            $r    = $res[$k] ?? null;
            $done = $r !== null;
            $pct  = ($r && $r['best_pct'] !== null) ? round((float)$r['best_pct'], 1) : null;

            if ($done) {
                $att++;
                if ($pct !== null) { $sum += $pct; $n++; $best = ($best === null) ? $pct : max($best, $pct); }
                if (!empty($r['last_date']) && ($last === null || $r['last_date'] > $last)) $last = $r['last_date'];
            }
            $exams[] = [
                'exam_id'   => $e['exam_id'],
                'title'     => $e['title'],
                'exam_date' => $e['exam_date'],
                'done'      => $done,
                'attempts'  => $done ? (int)$r['attempts'] : 0,
                'pct'       => $pct,
                'last_date' => $done ? ($r['last_date'] ?? null) : null,
            ];
            $seen[$k] = ['done' => $done, 'pct' => $pct];
        }

        $total = count($exams);
        $out['courses'][] = [
            'id'         => (int)$c['id'],
            'name'       => $c['name'],
            'subtitle'   => $c['subtitle'],
            'tone'       => $c['tone_gradient'] ?: 'linear-gradient(135deg,#7a1122 0%,#a31528 100%)',
            'enrolled_at'=> $c['enrolled_at'],
            'expires_at' => $c['expires_at'],
            'total'      => $total,
            'attempted'  => $att,
            'pending'    => $total - $att,
            'completion' => $total ? round($att / $total * 100, 1) : 0,
            'avg'        => $n ? round($sum / $n, 1) : null,
            'best'       => $best,
            'last_date'  => $last,
            'exams'      => $exams,
        ];
    }

    /* সামগ্রিক হিসাব (ইউনিক পরীক্ষা ধরে) */
    $total = count($seen); $att = 0; $sum = 0.0; $n = 0; $best = null;
    foreach ($seen as $v) {
        if ($v['done']) $att++;
        if ($v['pct'] !== null) { $sum += $v['pct']; $n++; $best = ($best === null) ? $v['pct'] : max($best, $v['pct']); }
    }
    $out['overall'] = [
        'courses'    => count($courses),
        'total'      => $total,
        'attempted'  => $att,
        'pending'    => $total - $att,
        'completion' => $total ? round($att / $total * 100, 1) : 0,
        'avg'        => $n ? round($sum / $n, 1) : null,
        'best'       => $best,
    ];
    return $out;
}

/* স্কোর অনুযায়ী রং: ≥৭০ সবুজ, ৪০–৬৯ সোনালি, <৪০ লাল */
function cp_score_color($pct): string {
    if ($pct === null) return '#6b7d72';
    return $pct >= 70 ? '#00693e' : ($pct >= 40 ? '#d9a441' : '#f42a41');
}