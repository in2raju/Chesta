<?php
session_start();
require 'db.php';

$siteLogo = 'logo.png';

/* =============================================================
   LOGIN STATE
   ============================================================= */
$isLoggedIn  = isset($_SESSION['user']);
$userSession = $_SESSION['user'] ?? [];
$userId      = $userSession['user_id'] ?? $userSession['USER_ID'] ?? '';
$userTypeId  = (int)($userSession['user_type_id'] ?? 0);
$isAdmin     = in_array($userTypeId, [1, 2], true);

/* =============================================================
   URL PARAM — শুধু course_id
   ============================================================= */
$courseId = (int)($_GET['course_id'] ?? 0);

if ($courseId <= 0) {
    $_SESSION['flash_error'] = 'কোর্স নির্বাচন করুন।';
    header("Location: index_user.php#courses");
    exit();
}

/* =============================================================
   COURSE LOOKUP
   ============================================================= */
$course = null;

try {
    $st = $pdo->prepare("
        SELECT c.*,
               l.name       AS level_name,
               et.type_name AS type_name
        FROM courses c
        LEFT JOIN levels     l  ON l.id  = c.level_id
        LEFT JOIN exam_types et ON et.id = c.type_id
        WHERE c.id = ?
          AND (c.DELETE_DATE IS NULL OR c.DELETE_DATE = '0000-00-00 00:00:00')
        LIMIT 1
    ");
    $st->execute([$courseId]);
    $course = $st->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('course_view lookup failed: ' . $e->getMessage());
}

if (!$course) {
    $_SESSION['flash_error'] = 'কোর্সটি পাওয়া যায়নি।';
    header("Location: index_user.php#courses");
    exit();
}

/* ---------- Course info ---------- */
$courseTitle = $course['title_bn'] ?: $course['title'];
$levelName   = $course['level_name'] ?? '';
$typeName    = $course['type_name']  ?? '';

/* ---------- Subject ---------- */
$subjectText = '';
if (!empty($course['subject_line'])) {
    $subjectText = trim($course['subject_line']);
    $subjectText = preg_replace('/^বিষয়\s*[:：]\s*/u', '', $subjectText);
}

/* ---------- Job Category ---------- */
$jobCategory = 'Job Preparation';
$lower = mb_strtolower($levelName, 'UTF-8');
if (strpos($lower, 'বিসিএস') !== false || stripos($levelName, 'BCS') !== false) {
    $jobCategory = 'BCS Preparation';
} elseif (strpos($lower, 'ব্যাংক') !== false || stripos($levelName, 'Bank') !== false) {
    $jobCategory = 'Bank Job Preparation';
} elseif (strpos($lower, 'শিক্ষক') !== false || stripos($levelName, 'Teacher') !== false) {
    $jobCategory = 'Teacher Recruitment';
}

/* =============================================================
   ENROLLMENT CHECK
   admin সব দেখবে, student শুধু enrolled হলে exams শুরু করতে পারবে
   ============================================================= */
$isEnrolled = false;
$enrollmentInfo = null;

if (!$isAdmin && $isLoggedIn && $userId !== '') {
    try {
        $st = $pdo->prepare("
            SELECT id, status, enrollment_code, activated_at, expires_at
            FROM course_enrollments
            WHERE user_id = ?
              AND course_id = ?
              AND status IN ('active', 'completed')
              AND (DELETE_DATE IS NULL OR DELETE_DATE = '0000-00-00 00:00:00')
            LIMIT 1
        ");
        $st->execute([$userId, $courseId]);
        $enrollmentInfo = $st->fetch(PDO::FETCH_ASSOC);
        $isEnrolled = (bool)$enrollmentInfo;
    } catch (Throwable $e) {
        error_log('enrollment check failed: ' . $e->getMessage());
    }
}

/* ✅ পাবলিক/লগইন সবাই তালিকা দেখতে পারবে — শুধু "শুরু" করতে এনরোল দরকার */
$canStartExam  = $isAdmin || $isEnrolled;   // "শুরু করুন" বাটন দেখাবে কি?
$canViewExams  = true;                      // ✅ সবসময় তালিকা দেখাবে

/* =============================================================
   EXAM FETCH — শুধু course_id দিয়ে
   ============================================================= */
$exams = [];

try {
    $st = $pdo->prepare("
        SELECT *
        FROM exams_info
        WHERE AUTHORIZED_STATUS = 'Y'
          AND (DELETE_DATE IS NULL OR DELETE_DATE = '0000-00-00 00:00:00')
          AND course_id = :course_id
        ORDER BY title ASC
    ");
    $st->execute([':course_id' => $courseId]);
    $exams = $st->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('course_view fetch failed: ' . $e->getMessage());
    $exams = [];
}

$totalExams = count($exams);
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= htmlspecialchars($courseTitle) ?></title>
    <link rel="icon" type="image/png" href="<?= htmlspecialchars($siteLogo) ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }

        html, body {
            font-family:
                -apple-system, BlinkMacSystemFont,
                'Segoe UI', Roboto,
                'Noto Sans Bengali', 'Noto Sans',
                'Kalpurush', 'SolaimanLipi',
                'Nirmala UI', 'Vrinda',
                sans-serif;
            background: #f8faf8;
            color: #10231a;
            line-height: 1.75;
            -webkit-font-smoothing: antialiased;
        }

        body { padding: 24px 16px; }
        .container { max-width: 900px; margin: 0 auto; }

        /* ---------- HEADER ---------- */
        .head {
            background: linear-gradient(135deg, #024a2c 0%, #00693e 100%);
            color: #fff;
            border-radius: 16px;
            padding: 26px 24px;
            margin-bottom: 22px;
            box-shadow: 0 10px 30px -12px rgba(2,74,44,0.35);
        }
        .back {
            display: inline-block;
            color: rgba(255,255,255,0.9);
            text-decoration: none;
            font-size: 14px;
            margin-bottom: 12px;
            font-weight: 500;
        }
        .back:hover { color: #fff; }

        .badge-row {
            display: flex;
            gap: 8px;
            flex-wrap: wrap;
            margin-bottom: 12px;
            align-items: center;
        }
        .job-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,213,74,0.25);
            border: 1px solid rgba(255,213,74,0.4);
            color: #ffd54a;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 12.5px;
            font-weight: 700;
            letter-spacing: 0.03em;
        }
        .type-badge,
        .level-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(255,255,255,0.15);
            border: 1px solid rgba(255,255,255,0.3);
            color: #fff;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 12.5px;
            font-weight: 700;
        }
        .enroll-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(34,197,94,0.28);
            border: 1px solid rgba(34,197,94,0.55);
            color: #86efac;
            padding: 5px 14px;
            border-radius: 20px;
            font-size: 12.5px;
            font-weight: 700;
        }
        .job-badge i, .type-badge i, .level-badge i, .enroll-badge i { font-size: 12px; }

        .head h1 {
            font-size: 24px;
            font-weight: 700;
            margin-bottom: 6px;
            line-height: 1.45;
        }
        .head h1 em {
            font-style: normal;
            color: #ffd54a;
            font-size: 16px;
            display: block;
            margin-top: 4px;
            font-weight: 600;
            opacity: 0.95;
        }
        .head .count {
            font-size: 15px;
            color: rgba(255,255,255,0.92);
            display: flex;
            align-items: center;
            gap: 8px;
            flex-wrap: wrap;
            margin-top: 8px;
        }
        .head .count b {
            font-size: 22px;
            color: #ffd54a;
            margin: 0 4px;
            font-weight: 700;
        }

        /* ---------- PUBLIC BANNER (Not logged in) ---------- */
        .public-banner {
            background: linear-gradient(135deg, #eef6ff 0%, #dbeafe 100%);
            border: 1.5px solid #93c5fd;
            border-radius: 14px;
            padding: 18px 20px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
        }
        .public-banner .pb-icon {
            font-size: 28px;
            color: #1d4ed8;
            flex-shrink: 0;
        }
        .public-banner .pb-text {
            flex: 1;
            min-width: 200px;
            font-size: 14.5px;
            color: #1e3a8a;
            line-height: 1.6;
        }
        .public-banner .pb-text strong {
            display: block;
            font-size: 15.5px;
            color: #1e40af;
            margin-bottom: 3px;
        }
        .public-banner .pb-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
            color: #fff;
            text-decoration: none;
            padding: 10px 22px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 14px;
            white-space: nowrap;
            box-shadow: 0 6px 16px -6px rgba(29,78,216,0.55);
            transition: transform 0.15s, box-shadow 0.2s;
        }
        .public-banner .pb-btn:hover {
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 10px 22px -8px rgba(29,78,216,0.65);
        }

        /* ---------- ENROLL BANNER (Logged in but not enrolled) ---------- */
        .enroll-banner {
            background: linear-gradient(135deg, #fff8e1 0%, #fef3c7 100%);
            border: 1.5px solid #fcd34d;
            border-radius: 14px;
            padding: 18px 20px;
            margin-bottom: 18px;
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
        }
        .enroll-banner .eb-icon {
            font-size: 28px;
            color: #d97706;
            flex-shrink: 0;
        }
        .enroll-banner .eb-text {
            flex: 1;
            min-width: 200px;
            font-size: 14.5px;
            color: #78350f;
            line-height: 1.6;
        }
        .enroll-banner .eb-text strong {
            display: block;
            font-size: 15.5px;
            color: #78350f;
            margin-bottom: 3px;
        }
        .enroll-banner .eb-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: linear-gradient(135deg, #d97706, #f59e0b);
            color: #fff;
            text-decoration: none;
            padding: 11px 24px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 14px;
            white-space: nowrap;
            box-shadow: 0 6px 16px -6px rgba(217,119,6,0.55);
            transition: transform 0.15s, box-shadow 0.2s;
        }
        .enroll-banner .eb-btn:hover {
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 10px 22px -8px rgba(217,119,6,0.65);
        }

        /* ---------- EXAM LIST ---------- */
        .exam-list {
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .exam-item {
            background: #fff;
            border: 1px solid #e1e9e3;
            border-radius: 14px;
            padding: 18px 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            transition: border-color 0.2s, box-shadow 0.2s, transform 0.2s;
        }
        .exam-item:hover {
            border-color: #00693e;
            box-shadow: 0 10px 24px -12px rgba(2,74,44,0.2);
            transform: translateY(-2px);
        }
        .exam-num {
            width: 40px;
            height: 40px;
            border-radius: 12px;
            background: #e4f2e9;
            color: #024a2c;
            font-weight: 700;
            font-size: 15px;
            display: grid;
            place-items: center;
            flex-shrink: 0;
        }
        .exam-info { flex: 1; min-width: 0; }
        .exam-title {
            font-size: 16px;
            font-weight: 600;
            color: #10231a;
            margin-bottom: 4px;
            line-height: 1.5;
        }
        .exam-remarks {
            font-size: 13px;
            color: #6b7280;
            font-style: italic;
            line-height: 1.6;
            margin: 4px 0 8px;
            display: flex;
            align-items: flex-start;
            gap: 6px;
        }
        .exam-remarks i {
            color: #d9a441;
            font-size: 13px;
            margin-top: 3px;
            flex-shrink: 0;
        }
        .exam-meta {
            font-size: 13px;
            color: #5a6c62;
            display: flex;
            gap: 14px;
            flex-wrap: wrap;
        }
        .exam-meta span {
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }
        .exam-meta i { color: #00693e; font-size: 13px; }

        /* ---------- BUTTONS ---------- */
        .exam-btn {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 10px 18px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 13.5px;
            text-decoration: none;
            background: linear-gradient(135deg, #00693e, #0a8f55);
            color: #fff;
            white-space: nowrap;
            flex-shrink: 0;
            transition: transform 0.15s, box-shadow 0.2s;
        }
        .exam-btn:hover {
            color: #fff;
            transform: translateY(-2px);
            box-shadow: 0 10px 20px -8px #00693e;
        }

        /* ✅ ভর্তি হোন (public) */
        .exam-btn.public {
            background: linear-gradient(135deg, #1d4ed8, #3b82f6);
        }
        .exam-btn.public:hover {
            box-shadow: 0 10px 20px -8px #1d4ed8;
        }

        /* ✅ এনরোল করুন (logged in, not enrolled) */
        .exam-btn.enroll {
            background: linear-gradient(135deg, #d97706, #f59e0b);
        }
        .exam-btn.enroll:hover {
            box-shadow: 0 10px 20px -8px #d97706;
        }

        /* ---------- EMPTY ---------- */
        .empty {
            background: #fff;
            border: 2px dashed #e1e9e3;
            border-radius: 16px;
            padding: 60px 20px;
            text-align: center;
        }
        .empty i {
            font-size: 48px;
            color: #cbd5c4;
            display: block;
            margin-bottom: 12px;
        }
        .empty h3 {
            font-size: 18px;
            font-weight: 700;
            color: #10231a;
            margin-bottom: 6px;
        }
        .empty p {
            color: #5a6c62;
            font-size: 14px;
        }
        .empty-diag {
            margin-top: 16px;
            padding: 14px 16px;
            background: #f4f8f5;
            border-radius: 10px;
            font-size: 13px;
            text-align: left;
            color: #5a6c62;
            line-height: 1.8;
        }
        .empty-diag strong { color: #10231a; }
        .empty-diag code {
            background: #fff;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 12.5px;
            color: #024a2c;
            border: 1px solid #e1e9e3;
        }
        .empty-diag .mini-btn {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            margin-top: 10px;
            padding: 7px 14px;
            border-radius: 30px;
            font-weight: 700;
            font-size: 12px;
            text-decoration: none;
            background: linear-gradient(135deg, #00693e, #0a8f55);
            color: #fff;
        }
        .empty-diag .mini-btn:hover { color: #fff; }

        /* ---------- FOOTER HELP ---------- */
        .footer-help {
            margin-top: 22px;
            text-align: center;
            font-size: 13.5px;
            color: #5a6c62;
        }
        .footer-help a {
            color: #00693e;
            font-weight: 700;
            text-decoration: none;
        }
        .footer-help a:hover { text-decoration: underline; }

        @media (max-width: 600px) {
            .exam-item {
                flex-direction: column;
                align-items: stretch;
                gap: 12px;
            }
            .exam-btn {
                justify-content: center;
                width: 100%;
            }
            .public-banner,
            .enroll-banner {
                flex-direction: column;
                align-items: stretch;
                text-align: center;
            }
            .public-banner .pb-btn,
            .enroll-banner .eb-btn {
                justify-content: center;
            }
        }
    </style>
</head>
<body>

<div class="container">

    <!-- =========================================================
         HEADER
         ========================================================= -->
    <div class="head">
        <a href="index_user.php#courses" class="back">
            <i class="fa-solid fa-arrow-left"></i> কোর্সে ফিরে যান
        </a>

        <div class="badge-row">
            <span class="job-badge">
                <i class="fa-solid fa-briefcase"></i>
                <?= htmlspecialchars($jobCategory) ?>
            </span>

            <?php if ($typeName): ?>
                <span class="type-badge">
                    <i class="fa-solid fa-tag"></i>
                    <?= htmlspecialchars($typeName) ?>
                </span>
            <?php endif; ?>

            <?php if ($levelName): ?>
                <span class="level-badge">
                    <i class="fa-solid fa-layers"></i>
                    <?= htmlspecialchars($levelName) ?>
                </span>
            <?php endif; ?>

            <?php if ($isEnrolled): ?>
                <span class="enroll-badge">
                    <i class="fa-solid fa-circle-check"></i>
                    এনরোলড
                </span>
            <?php endif; ?>
        </div>

        <h1>
            <?= htmlspecialchars($courseTitle) ?>
            <?php if ($subjectText !== ''): ?>
                <em><?= htmlspecialchars($subjectText) ?></em>
            <?php endif; ?>
        </h1>

        <div class="count">
            <i class="fa-solid fa-book-open"></i>
            মোট <b><?= $totalExams ?></b> টি পরীক্ষা
            <?php if (!$canStartExam): ?>
                <span style="opacity:.85;">— এনরোল করলে শুরু করতে পারবেন</span>
            <?php endif; ?>
        </div>
    </div>

    <!-- =========================================================
         PUBLIC BANNER — লগইন করা নেই
         ========================================================= -->
    <?php if (!$isLoggedIn): ?>
        <div class="public-banner">
            <div class="pb-icon"><i class="fa-solid fa-user-plus"></i></div>
            <div class="pb-text">
                <strong>এই কোর্সে ভর্তি হতে চান?</strong>
                পরীক্ষাগুলোতে অংশ নিতে প্রথমে অ্যাকাউন্ট তৈরি করুন বা লগইন করুন — তারপর সহজেই এনরোল করতে পারবেন।
            </div>
            <a href="login.php" class="pb-btn">
                <i class="fa-solid fa-right-to-bracket"></i> লগইন / রেজিস্টার
            </a>
        </div>
    <?php endif; ?>

    <!-- =========================================================
         ENROLL BANNER — লগইন আছে কিন্তু এনরোল করা নেই
         ========================================================= -->
    <?php if ($isLoggedIn && !$isEnrolled && !$isAdmin): ?>
        <div class="enroll-banner">
            <div class="eb-icon"><i class="fa-solid fa-graduation-cap"></i></div>
            <div class="eb-text">
                <strong>আপনি এই কোর্সে এখনো এনরোল করেননি</strong>
                নিচের পরীক্ষাগুলো দেখতে পাচ্ছেন, তবে শুরু করতে হলে আগে কোর্সে এনরোল করুন।
            </div>
            <a href="enroll.php?course_id=<?= (int)$courseId ?>" class="eb-btn">
                <i class="fa-solid fa-graduation-cap"></i> এনরোল করুন
            </a>
        </div>
    <?php endif; ?>

    <!-- =========================================================
         CONTENT
         ========================================================= -->
    <?php if (empty($exams)): ?>

        <!-- EMPTY STATE -->
        <div class="empty">
            <i class="fa-solid fa-inbox"></i>
            <h3>কোনো পরীক্ষা পাওয়া যায়নি</h3>
            <p>এই কোর্সে এই মুহূর্তে কোনো পরীক্ষা নেই।</p>

            <?php if ($isAdmin): ?>
                <div class="empty-diag">
                    <strong>অ্যাডমিন ডায়াগনস্টিক:</strong><br>
                    Course ID: <code><?= (int)$courseId ?></code><br>
                    Course Title: <code><?= htmlspecialchars($courseTitle) ?></code><br>
                    Level ID (from course): <code><?= (int)$course['level_id'] ?></code><br>
                    Exam Type ID (from course): <code><?= (int)$course['type_id'] ?></code><br>
                    <br>
                    এই কোর্সে কোনো authorized পরীক্ষা নেই।<br>
                    <a href="create_exam.php" class="mini-btn">
                        <i class="fa-solid fa-plus"></i> পরীক্ষা যোগ করুন
                    </a>
                </div>
            <?php endif; ?>
        </div>

    <?php else: ?>

        <!-- EXAM LIST -->
        <div class="exam-list">
            <?php foreach ($exams as $i => $ex): ?>
                <div class="exam-item">
                    <div class="exam-num"><?= $i + 1 ?></div>

                    <div class="exam-info">

                        <div class="exam-title">
                            <?= htmlspecialchars($ex['title']) ?>
                        </div>

                        <?php if (!empty($ex['remarks'])): ?>
                            <div class="exam-remarks">
                                <i class="fa-solid fa-circle-info"></i>
                                <?= htmlspecialchars($ex['remarks']) ?>
                            </div>
                        <?php endif; ?>

                        <div class="exam-meta">
                            <?php if (!empty($ex['exam_date'])): ?>
                                <span>
                                    <i class="fa-solid fa-calendar-days"></i>
                                    <?= htmlspecialchars(date('d M Y', strtotime($ex['exam_date']))) ?>
                                </span>
                            <?php endif; ?>

                            <?php if ($typeName): ?>
                                <span>
                                    <i class="fa-solid fa-tag"></i>
                                    <?= htmlspecialchars($typeName) ?>
                                </span>
                            <?php endif; ?>

                            <?php if ($levelName): ?>
                                <span>
                                    <i class="fa-solid fa-layers"></i>
                                    <?= htmlspecialchars($levelName) ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if ($canStartExam): ?>
                        <!-- ✅ এনরোলড বা অ্যাডমিন — পরীক্ষা শুরু -->
                        <a href="view_exam.php?id=<?= urlencode($ex['exam_id']) ?>" class="exam-btn">
                            শুরু করুন <i class="fa-solid fa-arrow-right"></i>
                        </a>

                    <?php elseif ($isLoggedIn): ?>
                        <!-- ✅ লগইন আছে কিন্তু এনরোল নেই — এনরোল করুন -->
                        <a href="enroll.php?course_id=<?= (int)$courseId ?>" class="exam-btn enroll">
                            <i class="fa-solid fa-graduation-cap"></i> এনরোল করুন
                        </a>

                    <?php else: ?>
                        <!-- ✅ পাবলিক — ভর্তি হোন (login.php) -->
                        <a href="login.php" class="exam-btn public">
                            <i class="fa-solid fa-user-plus"></i> ভর্তি হোন
                        </a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>

    <?php endif; ?>

    <!-- ---------- FOOTER HELP ---------- -->
    <?php if (empty($exams) === false && !$canStartExam): ?>
        <div class="footer-help">
            <?php if ($isLoggedIn): ?>
                কোর্সের সব পরীক্ষা দিতে <a href="enroll.php?course_id=<?= (int)$courseId ?>">এখানে এনরোল করুন</a>।
            <?php else: ?>
                পরীক্ষা শুরু করতে <a href="login.php">লগইন করুন</a> অথবা <a href="index_user.php#register">নতুন অ্যাকাউন্ট খুলুন</a>।
            <?php endif; ?>
        </div>
    <?php endif; ?>

</div>

</body>
</html>