<?php
/* =========================================================
   dashboard_my_courses.php — deshboard.php-এর জন্য "আমার কোর্স" সেকশন
   deshboard.php-তে "Question Analysis Section"-এর ঠিক আগে এই এক লাইন বসান:
        <?php include 'dashboard_my_courses.php'; ?>
   (deshboard.php-এর $pdo, $isPrivileged, $userId ভেরিয়েবল ব্যবহার করে; অ্যাডমিনের জন্য কিছু দেখায় না)
   ========================================================= */
if (!empty($isPrivileged) || !isset($pdo)) return;

require_once 'course_performance.php';

if (!isset($cpData)) {   // dashboard_pending.php আগেই হিসাব করে থাকলে আবার কোয়েরি চলবে না
    $cpData = get_course_performance($pdo, (string)($_SESSION['user']['user_id'] ?? ''), (string)($userId ?? ''));
}
$cpOv   = $cpData['overall'];
$cpList = $cpData['courses'];
$cpPct  = fn($v) => $v === null ? '—' : $v . '%';
?>

<div class="row g-4 mb-3">
    <div class="col-12">
        <div class="d-flex align-items-center justify-content-between flex-wrap gap-2 animate-card d5">
            <div class="section-heading mb-0">
                <span class="sh-dot" style="background:var(--teal);color:var(--teal)"></span>
                আমার কোর্স ও পারফরম্যান্স
            </div>
            <?php if ($cpList): ?>
                <a href="my_courses.php" class="btn-start">সব বিস্তারিত দেখুন</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php foreach ($cpData['verifying'] as $v): ?>
    <div class="callout-improve callout-warn animate-card d5">
        <i class="bi bi-hourglass-split fs-4" style="color:var(--gold)"></i>
        <div><strong><?= htmlspecialchars($v['name']) ?></strong> — পেমেন্ট যাচাই চলছে, অনুমোদনের পর কোর্স চালু হবে।</div>
    </div>
<?php endforeach; ?>

<?php if (!$cpList): ?>
    <div class="chart-card mb-4 animate-card d5">
        <p class="text-center py-3 mb-2" style="color:var(--mut)">আপনি এখনো কোনো কোর্সে ভর্তি হননি।</p>
        <p class="text-center mb-0"><a href="index.php#courses" class="btn-start">কোর্স দেখুন</a></p>
    </div>
<?php else: ?>

    <!-- সামগ্রিক পারফরম্যান্স -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-lg-3 animate-card d5">
            <div class="metric-card mc-1">
                <span class="mc-tag">কোর্স</span>
                <div class="mc-icon-wrap"><i class="bi bi-journal-bookmark"></i></div>
                <div class="mc-label">ভর্তি করা কোর্স</div>
                <div class="mc-value"><?= (int)$cpOv['courses'] ?></div>
                <div class="mc-sub">সক্রিয় কোর্স</div>
            </div>
        </div>
        <div class="col-6 col-lg-3 animate-card d5">
            <div class="metric-card mc-2">
                <span class="mc-tag">অগ্রগতি</span>
                <div class="mc-icon-wrap"><i class="bi bi-check2-square"></i></div>
                <div class="mc-label">সম্পন্ন পরীক্ষা</div>
                <div class="mc-value"><?= (int)$cpOv['attempted'] ?>/<?= (int)$cpOv['total'] ?></div>
                <div class="mc-sub"><?= $cpPct($cpOv['completion']) ?> সম্পন্ন · বাকি <?= (int)$cpOv['pending'] ?></div>
            </div>
        </div>
        <div class="col-6 col-lg-3 animate-card d6">
            <div class="metric-card mc-3">
                <span class="mc-tag">গড়</span>
                <div class="mc-icon-wrap"><i class="bi bi-bullseye"></i></div>
                <div class="mc-label">গড় স্কোর</div>
                <div class="mc-value"><?= $cpPct($cpOv['avg']) ?></div>
                <div class="mc-sub">সব কোর্স মিলিয়ে</div>
            </div>
        </div>
        <div class="col-6 col-lg-3 animate-card d6">
            <div class="metric-card mc-4">
                <span class="mc-tag">সেরা</span>
                <div class="mc-icon-wrap"><i class="bi bi-trophy"></i></div>
                <div class="mc-label">সর্বোচ্চ স্কোর</div>
                <div class="mc-value"><?= $cpPct($cpOv['best']) ?></div>
                <div class="mc-sub">এ পর্যন্ত</div>
            </div>
        </div>
    </div>

    <!-- কোর্সভিত্তিক পারফরম্যান্স -->
    <div class="row g-4 mb-4">
        <div class="col-12 animate-card d6">
            <div class="chart-card">
                <div class="chart-card-header">
                    <div class="chart-card-title">
                        <div class="chart-icon-badge">📚</div>
                        কোর্সভিত্তিক পারফরম্যান্স
                    </div>
                    <span class="chart-pill"><?= count($cpList) ?> টি কোর্স</span>
                </div>
                <?php foreach ($cpList as $i => $c):
                    $color = cp_score_color($c['avg']);
                ?>
                <div class="exam-item">
                    <div class="exam-dot" style="background:<?= $color ?>"></div>
                    <div class="exam-info">
                        <div class="exam-subj"><?= htmlspecialchars($c['name']) ?></div>
                        <?php if ($c['total'] === 0): ?>
                            <div class="exam-meta">এখনো কোনো পরীক্ষা যোগ করা হয়নি</div>
                        <?php else: ?>
                            <div class="exam-meta"><?= (int)$c['attempted'] ?>/<?= (int)$c['total'] ?> পরীক্ষা সম্পন্ন · বাকি <?= (int)$c['pending'] ?></div>
                            <div class="progress mt-2" style="height:6px;background:var(--surface)">
                                <div class="progress-bar" style="width:<?= (float)$c['completion'] ?>%;background:var(--g)"></div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="exam-right">
                        <div class="exam-subj" style="color:<?= $color ?>"><?= $cpPct($c['avg']) ?></div>
                        <div class="exam-date">গড় স্কোর</div>
                        <a href="exam_list.php?course_id=<?= (int)$c['id'] ?>" class="btn-start" style="margin-top:6px">পরীক্ষা দেখুন</a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
<?php endif; ?>