<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/functions.php';

function is_logged_in(): bool
{
    return isset($_SESSION['user_id']);
}

function current_user(): ?array
{
    if (!is_logged_in()) return null;
    return [
        'id'            => $_SESSION['user_id'],
        'name'          => $_SESSION['user_name'],
        'username'      => $_SESSION['username'],
        'role'          => $_SESSION['role'],
        'business_name' => $_SESSION['business_name'] ?? '',
    ];
}

function is_admin(): bool
{
    return is_logged_in() && $_SESSION['role'] === 'admin';
}

/** Redirect to login if not authenticated. Call at the top of every protected page. */
function require_login(): void
{
    if (!is_logged_in()) {
        header('Location: index.php');
        exit;
    }
}

/** Redirect non-admins away from admin-only pages. */
function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        header('Location: dashboard.php');
        exit;
    }
}
