<?php

function e(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8');
}

function money($amount): string
{
    return APP_CURRENCY . ' ' . number_format((float)$amount, 2);
}

/* ---------------- CSRF protection ---------------- */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . csrf_token() . '">';
}

function verify_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';
    if (!$token || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(400);
        die('Invalid or expired form submission (CSRF check failed). Please go back and try again.');
    }
}

/* ---------------- Flash messages ---------------- */
function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function get_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/* ---------------- Redirect helper ---------------- */
function redirect(string $to): void
{
    header('Location: ' . $to);
    exit;
}

/* ---------------- Pagination helper ---------------- */
function paginate(int $totalRows, int $perPage, int $currentPage): array
{
    $totalPages  = max(1, (int)ceil($totalRows / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset      = ($currentPage - 1) * $perPage;
    return compact('totalPages', 'currentPage', 'offset');
}

function pagination_links(string $baseUrl, array $params, int $currentPage, int $totalPages): string
{
    if ($totalPages <= 1) return '';
    $html = '<nav><ul class="pagination pagination-sm justify-content-center flex-wrap">';
    for ($i = 1; $i <= $totalPages; $i++) {
        $params['page'] = $i;
        $qs = http_build_query($params);
        $active = $i === $currentPage ? ' active' : '';
        $html .= "<li class=\"page-item{$active}\"><a class=\"page-link\" href=\"{$baseUrl}?{$qs}\">{$i}</a></li>";
    }
    $html .= '</ul></nav>';
    return $html;
}

/* ---------------- Input helpers ---------------- */
function post(string $key, $default = '')
{
    return $_POST[$key] ?? $default;
}

function get(string $key, $default = '')
{
    return $_GET[$key] ?? $default;
}

function clean_amount($val): float
{
    return round((float)str_replace(',', '', (string)$val), 2);
}
