-- =====================================================================
-- Daily Ledger - Database Schema
-- PHP 8+ / MySQL / PDO
-- Import this file in phpMyAdmin or via:  mysql -u root -p < schema.sql
-- =====================================================================

CREATE DATABASE IF NOT EXISTS daily_ledger CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE daily_ledger;

-- ---------------------------------------------------------------------
-- Users
-- ---------------------------------------------------------------------
CREATE TABLE users (
    id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name          VARCHAR(100)  NOT NULL,
    username      VARCHAR(50)   NOT NULL UNIQUE,
    email         VARCHAR(120)  DEFAULT NULL,
    phone         VARCHAR(30)   DEFAULT NULL,
    business_name VARCHAR(150)  DEFAULT NULL,
    password      VARCHAR(255)  NOT NULL,
    role          ENUM('admin','user') NOT NULL DEFAULT 'user',
    status        ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin  (username: admin / password: Admin@123)
INSERT INTO users (name, username, email, business_name, password, role, status)
VALUES ('Administrator', 'admin', 'admin@example.com', 'My Shop',
        '$2y$10$9nhVkkahBbK/fuXr3mR1zOWNdll4pHEJKXw3go7gc5JsqotD7l4da', 'admin', 'active');
-- NOTE: the hash above is for password "Admin@123". Change it after first login.

-- ---------------------------------------------------------------------
-- Income / Expense Heads (categories) - per user, customizable
-- ---------------------------------------------------------------------
CREATE TABLE income_heads (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    name       VARCHAR(100) NOT NULL,
    status     ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_income_head (user_id, name)
) ENGINE=InnoDB;

CREATE TABLE expense_heads (
    id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id    INT UNSIGNED NOT NULL,
    name       VARCHAR(100) NOT NULL,
    status     ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY uniq_expense_head (user_id, name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Income entries
-- ---------------------------------------------------------------------
CREATE TABLE incomes (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL,
    entry_date     DATE NOT NULL,
    head_id        INT UNSIGNED NOT NULL,
    amount         DECIMAL(14,2) NOT NULL DEFAULT 0,
    payment_method ENUM('Cash','Bank','Mobile Banking','Card','Other') NOT NULL DEFAULT 'Cash',
    note           VARCHAR(255) DEFAULT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (head_id) REFERENCES income_heads(id),
    INDEX idx_income_date (user_id, entry_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Expense entries
-- ---------------------------------------------------------------------
CREATE TABLE expenses (
    id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id        INT UNSIGNED NOT NULL,
    entry_date     DATE NOT NULL,
    head_id        INT UNSIGNED NOT NULL,
    amount         DECIMAL(14,2) NOT NULL DEFAULT 0,
    payment_method ENUM('Cash','Bank','Mobile Banking','Card','Other') NOT NULL DEFAULT 'Cash',
    note           VARCHAR(255) DEFAULT NULL,
    created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (head_id) REFERENCES expense_heads(id),
    INDEX idx_expense_date (user_id, entry_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Parties (Customers & Suppliers) - Due Ledger
-- ---------------------------------------------------------------------
CREATE TABLE parties (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id      INT UNSIGNED NOT NULL,
    type         ENUM('customer','supplier') NOT NULL,
    name         VARCHAR(120) NOT NULL,
    phone        VARCHAR(30)  DEFAULT NULL,
    address      VARCHAR(255) DEFAULT NULL,
    opening_due  DECIMAL(14,2) NOT NULL DEFAULT 0,
    status       ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_party_type (user_id, type)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Due Transactions (new due added / payment received-paid)
-- current_due = opening_due + SUM(type=due) - SUM(type=payment)
-- ---------------------------------------------------------------------
CREATE TABLE due_transactions (
    id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    party_id     INT UNSIGNED NOT NULL,
    user_id      INT UNSIGNED NOT NULL,
    entry_date   DATE NOT NULL,
    type         ENUM('due','payment') NOT NULL,
    amount       DECIMAL(14,2) NOT NULL DEFAULT 0,
    note         VARCHAR(255) DEFAULT NULL,
    created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (party_id) REFERENCES parties(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_due_party (party_id, entry_date)
) ENGINE=InnoDB;

-- ---------------------------------------------------------------------
-- Seed a few default heads for the default admin user (id = 1)
-- ---------------------------------------------------------------------
INSERT INTO income_heads (user_id, name) VALUES
(1,'Product Sales'),(1,'Service Income'),(1,'Other Income');

INSERT INTO expense_heads (user_id, name) VALUES
(1,'Purchase'),(1,'Rent'),(1,'Utility Bill'),(1,'Salary'),(1,'Transport'),(1,'Other Expense');
