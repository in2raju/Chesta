<?php
/* =========================================================
   dashboard_pending.php
   শিক্ষার্থীর ড্যাশবোর্ডে এক্সাম সংখ্যা ও "বাকি এক্সামসমূহ" এখন শুধু
   ভর্তি করা (active) কোর্সের পরীক্ষা থেকে আসে।

   deshboard.php-তে এই লাইনের ঠিক নিচে বসান:
        $completionRate = $totalExams > 0 ? round(($completedExams / $totalExams) * 100, 1) : 0;
   বসানোর লাইন:
        require 'dashboard_pending.php';

   কোর্স ↔ পরীক্ষা মিল: courses.level_id = exams_info.level_id এবং courses.type_id = exams_info.exam_type_id
   (course_performance.php-এর CP_AUTO_MATCH; exams_info-এ course_id কলাম নেই)
   অ্যাডমিনের জন্য কিছু বদলায় না।
   ========================================================= */
if (!empty($isPrivileged) || !isset($pdo)) return;

require_once 'course_performance.php';

$cpData = get_course_performance($pdo, (string)($_SESSION['user']['user_id'] ?? ''), (string)($userId ?? ''));

/* বাকি পরীক্ষার তালিকা (কোর্সের নামসহ, একই পরীক্ষা একবারই) */
$pendingAll = [];
$pendingSeen = [];
foreach ($cpData['courses'] as $pCourse) {
    foreach ($pCourse['exams'] as $pExam) {
        $pKey = (string)$pExam['exam_id'];
        if ($pExam['done'] || isset($pendingSeen[$pKey])) continue;
        $pendingSeen[$pKey] = true;
        $pendingAll[] = [
            'exam_id'     => $pExam['exam_id'],
            'title'       => $pExam['title'],
            'exam_date'   => $pExam['exam_date'],
            'course_name' => $pCourse['name'],
        ];
    }
}
// তারিখ অনুযায়ী (আগে যেটা আসছে সেটা আগে; তারিখ না থাকলে শেষে)
usort($pendingAll, function ($a, $b) {
    $da = $a['exam_date'] ?: '9999-12-31';
    $db = $b['exam_date'] ?: '9999-12-31';
    return strcmp($da, $db);
});

/* ড্যাশবোর্ডের ভেরিয়েবলগুলো ভর্তি করা কোর্স অনুযায়ী বদলে দেওয়া হলো */
$ovPending       = $cpData['overall'];
$totalExams      = (int)$ovPending['total'];
$completedExams  = (int)$ovPending['attempted'];
$pendingExams    = (int)$ovPending['pending'];
$completionRate  = (float)$ovPending['completion'];
$pendingExamList = array_slice($pendingAll, 0, 8);

if (!$cpData['results_ok']) {
    $examResultsTableExists = false;   // ফলাফল পড়া না গেলে ড্যাশবোর্ডের সতর্কবার্তা দেখাবে
}