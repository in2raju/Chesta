<?php
/**
 * Database configuration
 * Update these 4 values to match your hosting / XAMPP / WAMP setup.
 */
define('DB_HOST', 'sql207.infinityfree.com');
define('DB_NAME', 'if0_42992197_incomexdb');
define('DB_USER', 'if0_42992197');
define('DB_PASS', 'k9FY0ysN4JNN');

// Application base settings
define('APP_NAME', 'Daily Ledger');
define('APP_CURRENCY', '৳'); // change to $, ₹, etc. as needed

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
}
